package com.example.macstudent.parkingticket;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.macstudent.parkingticket.db.AppDataBase;
import com.example.macstudent.parkingticket.db.TicketDao;
import com.example.macstudent.parkingticket.model.Ticket;
import com.example.macstudent.parkingticket.model.User;
import com.example.macstudent.parkingticket.util.Utils;

import java.util.Date;

public class AddParkingTicketActivity extends AppCompatActivity
{
    private TextView txtCurrentDate;
    private TextView txtTotalCost;
    private EditText edtVehicleNumber;
    private ImageView imgVehicleBrand;
    private Spinner spnVehicleBrand;
    private Spinner spnColor;
    private Spinner spnLane;
    private Spinner spnLevel;
    private Spinner spnPayment;
    private Spinner vehiclemoney;
    private TextView parkingmoney;

    private String parkingTime = "1/2 Hour";
    private int price = 20;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_parking_ticket);

        parkingmoney=findViewById(R.id.parkingmoney);
        txtCurrentDate = findViewById(R.id.txtCurrentDate);
        txtCurrentDate.setText(Utils.formatDate(new Date()));

        User user =  ((MyApplication)getApplicationContext()).getUser();
        edtVehicleNumber = findViewById(R.id.edtVehicleNumber);
        edtVehicleNumber.setText(user != null ? user.getVehicleNumber() : "");

        txtTotalCost = findViewById(R.id.txtTotalCost);
        txtTotalCost.setText(String.format("$ %.02f", 20.0));

        imgVehicleBrand = findViewById(R.id.imgVehicleBrand);
      //  imgVehicleBrand.setBackgroundResource(R.drawable.twowheeler);


        spnVehicleBrand = findViewById(R.id.spnVehicleBrand);
        spnVehicleBrand.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            @SuppressLint("SetTextI18n")
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                loadVehicleBrandIcon(spnVehicleBrand.getSelectedItem().toString());
                if(spnVehicleBrand.getSelectedItem().toString().equals("Two Wheeler")){
                    parkingmoney.setText("20Rs");
                    txtTotalCost.setText("20Rs");
                    price=20;




                }
                if(spnVehicleBrand.getSelectedItem().toString().equals("Car")){
                    parkingmoney.setText("30Rs");
                    txtTotalCost.setText("30Rs");
                    price=30;

                }
                if(spnVehicleBrand.getSelectedItem().toString().equals("Tempo")){
                    parkingmoney.setText("40Rs");
                    txtTotalCost.setText("40Rs");
                    price=40;

                }
                if(spnVehicleBrand.getSelectedItem().toString().equals("Truck")){
                    parkingmoney.setText("50Rs");
                    txtTotalCost.setText("50Rs");
                    price=50;

                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {}
        });

        spnColor = findViewById(R.id.spnColor);
        spnLane = findViewById(R.id.spnLane);
        spnLevel = findViewById(R.id.spnLevel);
        spnPayment = findViewById(R.id.spnPayment);
    }

    public void onRadioButtonClicked(View view)
    {
        if (!((RadioButton)view).isChecked()) {
            return;
        }




    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.add_ticket, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch (item.getItemId())
        {
            case R.id.action_save:
                if (valid()) {
                    showConfirmationDialog();
                }
                break;
            default:
                break;
        }

        return true;
    }

    private void loadVehicleBrandIcon(String filename)
    {
        int id = imgVehicleBrand.getContext().getResources().getIdentifier(
                filename.toLowerCase().replace('-','_'),
                "drawable", getPackageName());
        imgVehicleBrand.setBackgroundResource(id);
    }

    private boolean valid()
    {
        if (Utils.isEmpty(edtVehicleNumber))
        {
            edtVehicleNumber.setError("Please enter a valid vehicle number.");
            return false;
        }

        return true;
    }

    private void showConfirmationDialog()
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Confirmation");
        builder.setMessage("Are you sure you want to print the ticket?");
        builder.setCancelable(false);
        builder.setIcon(android.R.drawable.ic_menu_help);
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int which){
                addTicket();
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int which){}
        });

        builder.show();
    }

    private void addTicket()
    {
        AppDataBase database = AppDataBase.getAppDataBase(this);
        TicketDao dao = database.ticketDao();

        Ticket ticket = new Ticket();
        ticket.setId(dao.findMaxId() + 1);
        ticket.setDate(txtCurrentDate.getText().toString());
        ticket.setParkingLane(spnLane.getSelectedItem().toString());
        ticket.setParkingSpot(spnLevel.getSelectedItem().toString());
        ticket.setParkingTime(parkingTime);
        ticket.setPaymentMethod(spnPayment.getSelectedItem().toString());
        ticket.setPrice(price);
        ticket.setUserId(((MyApplication)getApplicationContext()).getUser().getId());
        ticket.setVehicleNumber(edtVehicleNumber.getText().toString());
        ticket.setVehicleMaker(spnVehicleBrand.getSelectedItem().toString());
        ticket.setVehicleColor(spnColor.getSelectedItem().toString());

        dao.insert(ticket);

        Intent intent = new Intent(this, HomeActivity.class);
        startActivity(intent);
    }
}
